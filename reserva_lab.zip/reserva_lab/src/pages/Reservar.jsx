import React, { useState } from 'react';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import '../utils/firebase';

export default function Reservar() {
  const [fecha, setFecha] = useState('');
  const [hora, setHora] = useState('');
  const [actividad, setActividad] = useState('');
  const [responsable, setResponsable] = useState('');

  const handleSubmit = async () => {
    const db = getFirestore();
    try {
      await addDoc(collection(db, 'reservas'), {
        fecha,
        hora,
        actividad,
        responsable
      });
      alert('Reserva registrada correctamente');
    } catch (error) {
      alert('Error al registrar reserva: ' + error.message);
    }
  };

  return (
    <div>
      <h2>Reservar laboratorio</h2>
      <input type='date' value={fecha} onChange={e => setFecha(e.target.value)} />
      <input type='time' value={hora} onChange={e => setHora(e.target.value)} />
      <input type='text' value={actividad} onChange={e => setActividad(e.target.value)} placeholder='Tipo de actividad' />
      <input type='text' value={responsable} onChange={e => setResponsable(e.target.value)} placeholder='Responsable' />
      <button onClick={handleSubmit}>Enviar</button>
    </div>
  );
}